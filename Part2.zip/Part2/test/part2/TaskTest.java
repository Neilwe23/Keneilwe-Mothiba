/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part2;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;
import org.testng.annotations.Test;



/**
 *
 * @author mothi
 */
class TaskTest {

    @Test
    void testCheckTaskDescriptionSuccess() {
        Task task = new Task("Login Feature", 1, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertTrue(task.checkTaskDescription(), "Task description should be valid");
    }

    @Test
    void testCheckTaskDescriptionFailure() {
        Task task = new Task("Login Feature", 1, "This is a very long task description that exceeds fifty characters", "Robyn Harrison", 8, "To Do");
        assertFalse(task.checkTaskDescription(), "Task description should be invalid");
    }

    @Test
    void testCreateTaskID() {
        Task task = new Task("Add Task Feature", 1, "Create Add Task feature to add task users", "Mike Smith", 10, "Doing");
        assertEquals("AD:1:ITH", task.createTaskID(), "Task ID should be 'AD:1:ITH'");
    }

    @Test
    void testReturnTaskDuration() {
        Task task = new Task("Login Feature", 1, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals(8, task.returnTaskDuration(), "Task duration should be 8 hours");
    }
    }
    

