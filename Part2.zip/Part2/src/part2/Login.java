/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part2;

import java.util.ArrayList;

/**
 *
 * @author mothi
 */


class Login {
    private String username;
    private String password;
    
    public boolean checkUserName(String username) {
        // Check if username contains an underscore and is no more than 5 characters
        return username.contains("_") && username.length() <= 5;
    }
    
    public boolean checkPasswordComplexity(String password) {
        // Check password complexity: at least 8 characters, contains a number, a capital letter, and a special character
        boolean hasUppercase = !password.equals(password.toLowerCase());
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSpecialChar = password.matches(".*[!@#$%^&*()].*");
        return password.length() >= 8 && hasUppercase && hasNumber && hasSpecialChar;
    }
    
    public boolean registerUser(String username, String password) {
        if (!checkUserName(username)) {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return false;
        }
        if (!checkPasswordComplexity(password)) {
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            return false;
        }
        this.username = username;
        this.password = password;
        System.out.println("User registered successfully.");
        return true;
    }
    
    public boolean loginUser(String username, String password) {
        return false;
      
    }

    String registerUser(String username, String password, String firstName, String lastName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    boolean returnLoginStatus() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}


    

