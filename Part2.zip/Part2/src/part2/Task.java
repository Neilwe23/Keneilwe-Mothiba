/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part2;
import javax.swing.JOptionPane;

/**
 *
 * @author mothi
 */


public class Task {
    private final String taskName;
    private final int taskNumber;
    private final String taskDescription;
    private final String developerDetails;
    private final int taskDuration;
    private final String taskID;
    private final String taskStatus;

    // Constructor to initialize Task object
    public Task(String taskName, int taskNumber, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskNumber;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskID = createTaskID();
        this.taskStatus = taskStatus;
    }

    // Method to check if task description is within 50 characters
    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    // Method to create TaskID
    public String createTaskID() {
        String taskInitials = taskName.substring(0, 2).toUpperCase();
        String developerSuffix = developerDetails.substring(developerDetails.length() - 3).toUpperCase();
        return taskInitials + ":" + taskNumber + ":" + developerSuffix;
    }

    // Method to print Task Details (returns a string of task details)
    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\nDeveloper: " + developerDetails + "\nTask Number: " + taskNumber + 
                "\nTask Name: " + taskName + "\nTask Description: " + taskDescription + "\nTask ID: " + taskID + 
                "\nTask Duration: " + taskDuration + " hours\n";
    }

    // Method to return task duration
    public int returnTaskDuration() {
        return taskDuration;
    }
}


