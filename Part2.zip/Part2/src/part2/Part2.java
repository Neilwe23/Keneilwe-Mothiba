/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part2;

import java.util.Scanner;
import javax.swing.JOptionPane;


/**
 *
 * @author mothi
 */
public class Part2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        // Create a scanner object to read user input
        Scanner sc = new Scanner(System.in);
        
        // Create a Login object to manage users and login functionality
        Login loginSystem = new Login();

        // Register a new user
        System.out.println("Register a new user");
        System.out.print("Enter username: ");
        String username = sc.nextLine();
        System.out.print("Enter password: ");
        String password = sc.nextLine();
        System.out.print("Enter first name: ");
        String firstName = sc.nextLine();
        System.out.print("Enter last name: ");
        String lastName = sc.nextLine();
        boolean registrationMessage = false;

        // Register the user and show the message        String registrationMessage = loginSystem.registerUser(username, password, firstName, lastName);
        System.out.println(registrationMessage);

        // Attempt to log in the user
        System.out.println("\nLogin to the system");
        System.out.print("Enter username: ");
        String loginUsername = sc.nextLine();
        System.out.print("Enter password: ");
        String loginPassword = sc.nextLine();

        // Check if the login is successful and display the login status message
        if (loginSystem.loginUser(loginUsername, loginPassword)) {
            System.out.println(loginSystem.returnLoginStatus());
        } else {
            System.out.println(loginSystem.returnLoginStatus());
        }

        // Optional: Unit tests to verify the functionality of the methods
        
        // Test 1: Username correctly formatted
        boolean test1 = loginSystem.checkUserName("kyl_1");
        System.out.println("Test 1 (Username correctly formatted): " + (test1 ? "Passed" : "Failed"));

        // Test 2: Username incorrectly formatted
        boolean test2 = loginSystem.checkUserName("kyle!!!!!!!");
        System.out.println("Test 2 (Username incorrectly formatted): " + (!test2 ? "Passed" : "Failed"));

        // Test 3: Password meets complexity requirements
        boolean test3 = loginSystem.checkPasswordComplexity("Ch&&sec@ke99!");
        System.out.println("Test 3 (Password meets complexity): " + (test3 ? "Passed" : "Failed"));

        // Test 4: Password does not meet complexity requirements
        boolean test4 = loginSystem.checkPasswordComplexity("password");
        System.out.println("Test 4 (Password does not meet complexity): " + (!test4 ? "Passed" : "Failed"));

        // Test 5: Successful registration
        String test5 = loginSystem.registerUser("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith");
        System.out.println("Test 5 (Successful registration): " + (test5.equals("User successfully registered!") ? "Passed" : "Failed"));

        // Test 6: Registration with invalid username
        String test6 = loginSystem.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!", "Kyle", "Smith");
        System.out.println("Test 6 (Registration with invalid username): " + (test6.equals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.") ? "Passed" : "Failed"));

        // Test 7: Registration with invalid password
        String test7 = loginSystem.registerUser("kyl_1", "password", "Kyle", "Smith");
        System.out.println("Test 7 (Registration with invalid password): " + (test7.equals("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.") ? "Passed" : "Failed"));

        // Test 8: Successful login
        loginSystem.registerUser("john_d", "Password1!", "John", "Doe");
        boolean test8 = loginSystem.loginUser("john_d", "Password1!");
        System.out.println("Test 8 (Successful login): " + (test8 ? "Passed" : "Failed"));

        // Test 9: Failed login
        boolean test9 = loginSystem.loginUser("john_d", "wrongPassword");
        System.out.println("Test 9 (Failed login): " + (!test9 ? "Passed" : "Failed"));

        // Close the scanner
        sc.close();
        
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to EasyKanban");  // Welcome message

        System.out.print("How many tasks would you like to enter? ");
        int numTasks = scanner.nextInt();
        scanner.nextLine();  // Consume the newline character
        
        Task[] tasks = new Task[numTasks];  // Array to store tasks
        int totalHours = 0;

        // Entering task details
        for (int i = 0; i < numTasks; i++) {
            System.out.println("\nEntering details for Task " + (i + 1) + ":");
            
            System.out.print("Enter task name: ");
            String taskName = scanner.nextLine();
            
            System.out.print("Enter task description: ");
            String taskDescription = scanner.nextLine();
            if (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                i--;
                continue;  // Retry the task entry if description is too long
            }

            System.out.print("Enter developer details (First Last): ");
            String developerDetails = scanner.nextLine();

            System.out.print("Enter task duration (hours): ");
            int taskDuration = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character

            System.out.println("Select task status (To Do, Done, Doing): ");
            String taskStatus = scanner.nextLine();

            // Create and store the task
            Task task = new Task(taskName, i, taskDescription, developerDetails, taskDuration, taskStatus);
            tasks[i] = task;
            totalHours += taskDuration;

            // Display task details using JOptionPane
            JOptionPane.showMessageDialog(null, task.printTaskDetails(), "Task Details", JOptionPane.INFORMATION_MESSAGE);
        }

        // Display total hours across all tasks
        JOptionPane.showMessageDialog(null, "Total number of hours across all tasks: " + totalHours);
        
        scanner.close();

        
        
      
    }
    
}
